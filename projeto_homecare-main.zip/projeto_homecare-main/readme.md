
# criando um virtual environment
```sh
python -m venv .venv
```

# ativando o venv
```sh
source .venv/bin/activate
```

```sh
pip install django
```

não executar
```sh
django-admin startproject homecare
cd homecare
django-admin startapp escala
```


