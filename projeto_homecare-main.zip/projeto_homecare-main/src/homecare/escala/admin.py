from django.contrib import admin

from . import models
# Register your models here.

@admin.register(models.Paciente)
class PacienteAdmin(admin.ModelAdmin):
    pass


@admin.register(models.Profissional)
class ProfissionalAdmin(admin.ModelAdmin):
    pass


@admin.register(models.ProfissionalAgendado)
class ProfissionalAgendadoAdmin(admin.ModelAdmin):
    pass