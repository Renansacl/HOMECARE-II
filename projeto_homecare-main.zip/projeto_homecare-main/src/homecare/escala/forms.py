from django.forms import ModelForm

from . import models 

class  PacienteForm(ModelForm):
    class Meta:
        model=models.Paciente
        fields=["nome","idade","sexo"]