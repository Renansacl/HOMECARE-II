from django.shortcuts import render, HttpResponseRedirect
from django.urls import reverse
from django.http import Http404

from . import models, forms

def home(request):
    return render(request, "home.html", context={})


def list_pacientes(request):

    pacientes = models.Paciente.objects.all()

    contexto = {
        "pacientes": pacientes
    }

    return render(request, "lista_pacientes.html", context=contexto)


def paciente_details(request, id):
    paciente = models.Paciente.objects.get(id=id)
    contexto = {
        "paciente": paciente
    }

    return render(request, "paciente_detalhe.html", context=contexto)


def create_paciente(request):
    if request.method == "GET":
        form=forms.PacienteForm()
        return render(request, "create_paciente.html", context={"form":form})
    elif request.method == "POST":
        form = forms.PacienteForm(request.POST)
        if form.is_valid():
            paciente = form.save()
            return HttpResponseRedirect(reverse("paciente_detalhes", args=[paciente.id]))
        # TODO
        # lidar com formulario invalido
    else:
        # metodo inválido
        raise Http404()
    

def agenda(request):
    scala = models.ProfissionalAgendado.objects.all()
    return render(request,"scala.html",context={"scala":scala})
   