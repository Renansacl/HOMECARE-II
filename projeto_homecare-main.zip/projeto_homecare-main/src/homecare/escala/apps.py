from django.apps import AppConfig


class EscalaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'escala'
