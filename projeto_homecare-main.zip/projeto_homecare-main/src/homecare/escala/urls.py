from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("list_pacientes", views.list_pacientes, name="list_pacientes"),
    path("paciente/<id>", views.paciente_details, name="paciente_detalhes",),
    path("create_paciente", views.create_paciente, name="create_paciente"),
    path("agenda", views.agenda, name="agenda"),
    ]

