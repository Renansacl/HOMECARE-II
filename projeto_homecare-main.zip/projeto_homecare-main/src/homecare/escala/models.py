from django.db import models

# Create your models here.

class Paciente(models.Model):
    nome = models.CharField(max_length=56)
    idade = models.IntegerField()

    class SexoChoices(models.TextChoices):
        masculino = "masculino"
        feminino = "feminino"

    sexo = models.CharField(choices=SexoChoices, max_length=20)


    def __str__(self):
        return f"{self.nome} - {self.idade} - {self.sexo}"
    

class Profissional(models.Model):
    nome = models.CharField(max_length=56)

    class TipoChoices(models.TextChoices):
        cuidador = "Cuidador"
        enfermeiro = "Enfermeiro"

    tipo = models.CharField(choices=TipoChoices, max_length=20)

    def __str__(self):
        return f"{self.tipo} - {self.nome}"


class ProfissionalAgendado(models.Model):
    id_paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE)

    id_profissional = models.ForeignKey(Profissional, on_delete=models.CASCADE)
    hora_entrada = models.DateTimeField(blank=True, null=True)
    hora_saida = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f"{self.id_profissional} | {self.id_paciente}"


